/* ============================================================================
   THE PHANTOM WEIGHT FINDER — Build It With AI, Episode 28 (free giveaway)
   Google Sheets + Apps Script. It reads your own package log; it buys nothing, sends nothing.

   Tabs it reads (row 1 = headers, any order, extra columns ignored):
     Packages : Order | Service | Length | Width | Height | Weight   (inches, pounds)
     Boxes    : Box | Length | Width | Height [| Box cost]          (your own box sizes; Box cost optional)
     Rates    : Service | Pounds | Price                            (your own rate card, one zone)
     Settings : optional — divisor (139), threshold (1728)

   The rule it applies (USPS Postal Bulletin 22705, effective July 12, 2026): round each side UP
   to the whole inch; if length x width x height is more than 1,728 cubic inches, the package is
   billed at volume / 139, rounded up to the pound, whenever that beats its real weight (also
   rounded up). Priority Mail Express, Priority Mail, Ground Advantage, Parcel Select. Cubic-priced
   services use a different system and are set aside, not checked.
   v1.1 (Nov 14, 2026): add an optional "Box cost" column to Boxes (box + fill, per box) and the report
   also shows, for every suggested swap, the box cost change and the NET saving — a smaller box that
   costs more than the postage it saves is marked SWAP NOT WORTH IT. Without that column the report is
   exactly v1.0.
   Not shipping or tax advice; check your own carrier invoices.
   ============================================================================ */

/* EP28 — The Phantom Weight Finder — shipped engine core (pure; no I/O, no network). Follows SPEC.md exactly. */
var PHANTOM = (function () {
  var IN_SCOPE = { "priority mail express": 1, "priority mail": 1, "ground advantage": 1, "parcel select": 1 };
  var CUBIC = { "priority mail cubic": 1, "ground advantage cubic": 1 };
  var NEED = {
    packages: ["order", "service", "length", "width", "height", "weight"],
    boxes: ["box", "length", "width", "height"],
    rates: ["service", "pounds", "price"]
  };

  function norm(s) { return String(s == null ? "" : s).replace(/\s+/g, " ").trim(); }
  function fold(s) { return norm(s).toLowerCase(); }
  function hundredths(s) {               // "12.25" -> 1225 ; null if unreadable
    var t = norm(s);
    if (!/^\d+(\.\d{1,2})?$/.test(t)) return null;
    var p = t.split(".");
    return parseInt(p[0], 10) * 100 + (p[1] ? parseInt((p[1] + "0").slice(0, 2), 10) : 0);
  }
  function cents(s) {
    var t = norm(s).replace(/^\$/, "");
    if (!/^\d+(\.\d{1,2})?$/.test(t)) return null;
    var p = t.split(".");
    return parseInt(p[0], 10) * 100 + (p[1] ? parseInt((p[1] + "0").slice(0, 2), 10) : 0);
  }
  function ceilH(h) { return Math.floor((h + 99) / 100); }      // hundredths -> whole units, rounded UP
  function money(c) { var s = (c / 100).toFixed(2); return "$" + s.replace(/\B(?=(\d{3})+(?!\d))/g, ","); }

  function headerMap(rows, need) {
    if (!rows || !rows.length) return null;
    var h = rows[0].map(fold), m = {};
    for (var i = 0; i < need.length; i++) { var k = h.indexOf(need[i]); if (k < 0) return null; m[need[i]] = k; }
    return m;
  }
  function blank(row, idx) {
    for (var k in idx) { if (norm(row[idx[k]]) !== "") return false; }
    return true;
  }
  function dimOf(vol, divisor, threshold) { return vol > threshold ? Math.ceil(vol / divisor) : 0; }
  function sortedKey(a) { return a.slice().sort(function (x, y) { return x - y; }).join("x"); }

  function readSettings(rows) {
    var st = { divisor: 139, threshold: 1728, notes: [] };
    if (!rows || rows.length < 2) return st;
    for (var i = 1; i < rows.length; i++) {
      var k = fold(rows[i][0]), v = norm(rows[i][1]);
      if (k !== "divisor" && k !== "threshold") continue;
      var n = /^\d+$/.test(v) ? parseInt(v, 10) : null;
      if (k === "divisor") { if (n != null && n >= 100 && n <= 300) st.divisor = n; else st.notes.push("divisor unreadable — using 139"); }
      if (k === "threshold") { if (n != null && n >= 0 && n <= 20000) st.threshold = n; else st.notes.push("threshold unreadable — using 1728"); }
    }
    return st;
  }

  function run(pkgRows, boxRows, rateRows, setRows) {
    var st = readSettings(setRows);
    var D = st.divisor, T = st.threshold;
    var headerFail = [];
    // ---- rates ----
    var rates = {}, rateRefusals = [], usableRates = 0;
    var rm = headerMap(rateRows, NEED.rates);
    if (!rm) headerFail.push("Rates");
    else for (var r = 1; r < rateRows.length; r++) {
      var row = rateRows[r]; if (blank(row, rm)) continue;
      var sv = fold(row[rm.service]), lbS = norm(row[rm.pounds]), pc = cents(row[rm.price]);
      var lb = /^\d+$/.test(lbS) ? parseInt(lbS, 10) : null;
      if (!IN_SCOPE[sv]) { rateRefusals.push({ row: r + 1, reason: "unknown service: " + norm(row[rm.service]) }); continue; }
      if (lb == null || lb < 1 || lb > 70) { rateRefusals.push({ row: r + 1, reason: "pounds must be a whole number 1–70" }); continue; }
      if (pc == null) { rateRefusals.push({ row: r + 1, reason: "unreadable price" }); continue; }
      var key = sv + "|" + lb;
      if (rates.hasOwnProperty(key)) { rateRefusals.push({ row: r + 1, reason: "duplicate rate — the first was kept" }); continue; }
      rates[key] = pc; usableRates++;
    }
    // ---- boxes ----
    var boxes = [], boxRefusals = [], costCol = -1, costBad = 0;
    var bm = headerMap(boxRows, NEED.boxes);
    if (bm) costCol = boxRows[0].map(fold).indexOf("box cost");          // v1.1: optional Box cost column
    if (!bm) headerFail.push("Boxes");
    else for (var b = 1; b < boxRows.length; b++) {
      var br = boxRows[b]; if (blank(br, bm)) continue;
      var name = norm(br[bm.box]);
      var bl = hundredths(br[bm.length]), bw = hundredths(br[bm.width]), bh = hundredths(br[bm.height]);
      if (!name) { boxRefusals.push({ row: b + 1, reason: "no box name" }); continue; }
      if (bl == null || bw == null || bh == null || bl <= 0 || bw <= 0 || bh <= 0) { boxRefusals.push({ row: b + 1, reason: "unreadable size" }); continue; }
      var sides = [ceilH(bl), ceilH(bw), ceilH(bh)], vol = sides[0] * sides[1] * sides[2];
      var cost = null;
      if (costCol >= 0 && norm(br[costCol]) !== "") {
        cost = cents(br[costCol]);
        if (cost == null) { costBad++; boxRefusals.push({ row: b + 1, reason: "unreadable box cost — size kept, cost unknown" }); }
      }
      var bxo = { name: name, sides: sides, volume: vol, dim: dimOf(vol, D, T), order: boxes.length };
      if (costCol >= 0) bxo.cost = cost;
      boxes.push(bxo);
    }
    // ---- v1.1 swap math (only when the Boxes tab has a Box cost column) ----
    function swapOf(svc, act, bill, s3, sug) {
      var cur = null, key = sortedKey(s3);
      for (var j = 0; j < boxes.length; j++) if (sortedKey(boxes[j].sides) === key) { cur = boxes[j]; break; }
      var nb = Math.max(act, sug.dim), kb = svc + "|" + bill, kn = svc + "|" + nb;
      var ship = (rates.hasOwnProperty(kb) && rates.hasOwnProperty(kn)) ? rates[kb] - rates[kn] : null;
      var change = (cur && cur.cost != null && sug.cost != null) ? sug.cost - cur.cost : null;
      var net = (ship != null && change != null) ? ship - change : null;
      var status = ship == null ? "no rate — net unknown"
        : !cur ? "your box isn't in the Boxes list — net unknown"
        : change == null ? "add box costs to see the net"
        : net <= 0 ? "SWAP NOT WORTH IT" : "worth it";
      return { current: cur ? cur.name : "", shipCents: ship, changeCents: change, netCents: net, status: status };
    }
    // ---- packages ----
    var pm = headerMap(pkgRows, NEED.packages);
    var rowsIn = 0, checked = [], excluded = [], refused = [];
    if (!pm) {
      headerFail.push("Packages");
      for (var q = 1; q < (pkgRows ? pkgRows.length : 0); q++) {
        if (pkgRows[q].every(function (c) { return norm(c) === ""; })) continue;
        rowsIn++; refused.push({ row: q + 1, order: "", reason: "Packages header row unreadable" });
      }
    } else {
      var seen = {};
      for (var i = 1; i < pkgRows.length; i++) {
        var p = pkgRows[i]; if (blank(p, pm)) continue;
        rowsIn++;
        var ord = norm(p[pm.order]), rn = i + 1;
        if (!ord) { refused.push({ row: rn, order: "", reason: "no order id" }); continue; }
        if (seen[fold(ord)]) { refused.push({ row: rn, order: ord, reason: "duplicate order — the first row was kept" }); continue; }
        seen[fold(ord)] = 1;
        var svc = fold(p[pm.service]);
        if (CUBIC[svc]) { excluded.push({ row: rn, order: ord, reason: "cubic-priced: priced by cubic tier, not this rule" }); continue; }
        if (!IN_SCOPE[svc]) { refused.push({ row: rn, order: ord, reason: "unknown service: " + norm(p[pm.service]) }); continue; }
        var l = hundredths(p[pm.length]), w = hundredths(p[pm.width]), h = hundredths(p[pm.height]);
        if (l == null || w == null || h == null || l <= 0 || w <= 0 || h <= 0) { refused.push({ row: rn, order: ord, reason: "unreadable size" }); continue; }
        if (l > 10800 || w > 10800 || h > 10800) { refused.push({ row: rn, order: ord, reason: "a side over 108 inches" }); continue; }
        var wt = hundredths(p[pm.weight]);
        if (wt == null || wt <= 0) { refused.push({ row: rn, order: ord, reason: "unreadable weight" }); continue; }
        if (wt > 7000) { refused.push({ row: rn, order: ord, reason: "over 70 lb" }); continue; }
        var s3 = [ceilH(l), ceilH(w), ceilH(h)], v = s3[0] * s3[1] * s3[2];
        var dim = dimOf(v, D, T), act = ceilH(wt), bill = Math.max(act, dim), ph = bill - act;
        var rec = { row: rn, order: ord, service: norm(p[pm.service]), sides: s3, volume: v, dim: dim, actual: act,
                    billable: bill, phantom: ph, extraCents: 0, priced: true, note: "", suggestion: "" };
        if (ph > 0) {
          var kb = svc + "|" + bill, ka = svc + "|" + act;
          if (rates.hasOwnProperty(kb) && rates.hasOwnProperty(ka)) rec.extraCents = rates[kb] - rates[ka];
          else { rec.priced = false; rec.note = "no rate for " + (rates.hasOwnProperty(kb) ? act : bill) + " lb"; }
          var best = null;
          for (var k = 0; k < boxes.length; k++) {
            var bx = boxes[k];
            if (bx.volume >= v) continue;
            if (Math.max(act, bx.dim) !== act) continue;
            if (!best || bx.volume > best.volume) best = bx;
          }
          rec.suggestion = best ? best.name : "none in your list";
          if (costCol >= 0 && best) rec.swap = swapOf(svc, act, bill, s3, best);
        }
        checked.push(rec);
      }
    }
    var phantomRows = checked.filter(function (c) { return c.phantom > 0; });
    var extra = 0, phantomLb = 0, unpriced = 0;
    phantomRows.forEach(function (c) { phantomLb += c.phantom; if (c.priced) extra += c.extraCents; else unpriced++; });
    var readd = 0; checked.forEach(function (c) { readd += c.extraCents; });
    var worst = null;
    phantomRows.forEach(function (c) {
      if (!worst || c.extraCents > worst.extraCents || (c.extraCents === worst.extraCents && c.phantom > worst.phantom)) worst = c;
    });
    var reconOK = rowsIn === checked.length + excluded.length + refused.length;
    var readdOK = readd === extra;
    var swaps = null, swapReaddOK = true;
    if (costCol >= 0) {
      swaps = { swaps: 0, known: 0, shipCents: 0, changeCents: 0, netCents: 0, notWorth: 0 };
      var netSum = 0;
      phantomRows.forEach(function (c) {
        if (!c.swap) return;
        swaps.swaps++;
        if (c.swap.netCents == null) return;
        swaps.known++; swaps.shipCents += c.swap.shipCents; swaps.changeCents += c.swap.changeCents; netSum += c.swap.netCents;
        if (c.swap.netCents <= 0) swaps.notWorth++;
      });
      swaps.netCents = netSum;
      swapReaddOK = netSum === swaps.shipCents - swaps.changeCents;
    }
    var refShare = rowsIn ? refused.length / rowsIn : 0;
    var reasons = [];
    if (headerFail.length) reasons.push("header row unreadable: " + headerFail.join(", "));
    if (!reconOK) reasons.push("rows do not add up");
    if (!readdOK) reasons.push("money does not re-add");
    if (refShare > 0.10) reasons.push("more than 10% of rows refused");
    if (rm && usableRates === 0) reasons.push("no usable rates");
    if (costBad) reasons.push("a box cost is unreadable");
    if (!swapReaddOK) reasons.push("box savings do not re-add");
    return {
      settings: { divisor: D, threshold: T, notes: st.notes },
      rows: checked,
      phantom: phantomRows.slice().sort(function (a, b2) { return b2.extraCents - a.extraCents || b2.phantom - a.phantom || a.row - b2.row; }),
      boxes: boxes,
      excluded: excluded, refused: refused, rateRefusals: rateRefusals, boxRefusals: boxRefusals,
      totals: { rowsIn: rowsIn, checked: checked.length, phantomCount: phantomRows.length, phantomLb: phantomLb,
                extraCents: extra, unpriced: unpriced, excluded: excluded.length, refused: refused.length, usableRates: usableRates },
      worst: worst,
      swaps: swaps,
      recon: { ok: reconOK, readdOK: readdOK },
      trust: reasons.length ? "DO NOT TRUST THESE WEIGHTS" : "OK",
      trustReasons: reasons,
      money: money
    };
  }
  return { run: run, money: money, hundredths: hundredths, fold: fold };
})();

/* ---------------- the Sheets side: menu, read the tabs, write the report ---------------- */
function onOpen() {
  SpreadsheetApp.getUi().createMenu("Phantom Weight").addItem("Find phantom weight", "findPhantomWeight").addToUi();
}

function tabValues_(ss, name) {
  var sh = ss.getSheetByName(name);
  if (!sh) return null;
  return sh.getDataRange().getDisplayValues();
}

function findPhantomWeight() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var R = PHANTOM.run(tabValues_(ss, "Packages"), tabValues_(ss, "Boxes"), tabValues_(ss, "Rates"), tabValues_(ss, "Settings"));
  var M = PHANTOM.money, T = R.totals, S = R.swaps, out = [];
  var W = S ? 8 : 6;                                    // v1.1 columns only when Boxes has a Box cost column
  function row(a) { while (a.length < W) a.push(""); return a; }
  function signed(c) { return (c < 0 ? "−" : "+") + M(Math.abs(c)); }
  out.push([R.trust, R.trust === "OK" ? "every count below re-adds" : R.trustReasons.join(" · "), "", "", "", ""]);
  out.push(["USPS rule since July 12, 2026: each side rounded UP to the inch; over " + R.settings.threshold +
            " cubic inches, billed at volume ÷ " + R.settings.divisor + " (rounded up) when that beats the real weight", "", "", "", "", ""]);
  if (R.settings.notes.length) out.push(["Settings: " + R.settings.notes.join(" · "), "", "", "", "", ""]);
  out.push(["", "", "", "", "", ""]);
  out.push(["PHANTOM WEIGHT", T.phantomCount + " of " + T.checked + " packages", T.phantomLb + " lb billed that the scale never saw",
            M(T.extraCents) + " extra on your rate card", T.unpriced ? T.unpriced + " not priced (no rate on your card)" : "", ""]);
  if (S) out.push(["BOX SWAPS", "net known on " + S.known + " of " + S.swaps + " swaps", "postage saved " + M(S.shipCents),
                   "box cost change " + signed(S.changeCents), "net saving " + (S.netCents < 0 ? "−" + M(-S.netCents) : M(S.netCents)),
                   S.notWorth + " not worth it"]);
  if (R.worst) out.push(["Worst package", R.worst.order, R.worst.actual + " lb billed as " + R.worst.billable + " lb", R.worst.priced ? "+" + M(R.worst.extraCents) : R.worst.note, "box " + R.worst.sides.join(" x "), ""]);
  out.push(["", "", "", "", "", ""]);
  out.push(["Order", "Service", "Box (rounded)", "Real lb → billed lb", "Extra", "A box from your list that avoids it"]);
  if (S) out[out.length - 1].push("Box cost change", "Net saving");
  R.phantom.forEach(function (c) {
    var r = [c.order, c.service, c.sides.join(" x ") + " = " + c.volume + " cu in", c.actual + " → " + c.billable,
             c.priced ? M(c.extraCents) : c.note, c.suggestion];
    if (S) {
      var sw = c.swap;
      if (!sw) r.push("", "");
      else if (sw.netCents == null) r.push(sw.changeCents == null ? "" : signed(sw.changeCents), sw.status);
      else r.push(signed(sw.changeCents), (sw.netCents < 0 ? "−" + M(-sw.netCents) : M(sw.netCents)) + (sw.netCents <= 0 ? " · SWAP NOT WORTH IT" : ""));
    }
    out.push(r);
  });
  out.push(["", "", "", "", "", ""]);
  out.push(["YOUR BOXES", "Rounded", "Cubic inches", "Billed at least", S ? "Box cost" : "", ""]);
  R.boxes.forEach(function (b) {
    out.push([b.name, b.sides.join(" x "), b.volume, b.dim ? b.dim + " lb (DIM)" : "its real weight", S ? (b.cost == null ? "unknown" : M(b.cost)) : "", ""]);
  });
  out.push(["", "", "", "", "", ""]);
  out.push(["COUNT IN PUBLIC", "packages in " + T.rowsIn, "checked " + T.checked, "set aside " + T.excluded, "refused " + T.refused,
            R.recon.ok ? "adds up" : "DOES NOT ADD UP"]);
  R.excluded.forEach(function (e) { out.push(["row " + e.row, e.order, "set aside: " + e.reason, "", "", ""]); });
  R.refused.forEach(function (e) { out.push(["row " + e.row, e.order, "refused: " + e.reason, "", "", ""]); });
  R.rateRefusals.forEach(function (e) { out.push(["Rates row " + e.row, "", "refused: " + e.reason, "", "", ""]); });
  R.boxRefusals.forEach(function (e) { out.push(["Boxes row " + e.row, "", "refused: " + e.reason, "", "", ""]); });
  var rep = ss.getSheetByName("Phantom Weight") || ss.insertSheet("Phantom Weight");
  out = out.map(row);
  rep.clearContents();
  rep.getRange(1, 1, out.length, W).setValues(out);
  rep.getRange(1, 1, 1, W).setFontWeight("bold").setBackground(R.trust === "OK" ? "#e6f2ea" : "#b3261e").setFontColor(R.trust === "OK" ? "#1d4d2b" : "#ffffff");
  return R;
}
