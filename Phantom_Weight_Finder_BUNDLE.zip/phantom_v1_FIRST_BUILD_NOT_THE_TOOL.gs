/* NOT THE TOOL — the FIRST build from Build It With AI, Episode 28, kept so you can see what went wrong. Use phantom.gs. */
/* EP28 FIRST BUILD — what prompt 1 produced. WRONG: kept as a museum piece, NOT THE TOOL.
   Bugs (found by the checker): divides by 166 (the number in most articles it learned from; USPS moved to 139
   on July 12, 2026), rounds each side to the NEAREST inch, applies dimensional weight to every box no matter
   how small, compares against the fractional scale weight, reads anything parseFloat can swallow, refuses nothing. */
var PHANTOM_V1 = (function () {
  function run(pkgRows, boxRows, rateRows) {
    var rate = {};
    for (var i = 1; i < rateRows.length; i++) rate[rateRows[i][0] + "|" + rateRows[i][1]] = parseFloat(rateRows[i][2]);
    var out = [], extra = 0, lbs = 0, flagged = 0;
    for (var r = 1; r < pkgRows.length; r++) {
      var p = pkgRows[r];
      var L = Math.round(parseFloat(p[2]) || 0), W = Math.round(parseFloat(p[3]) || 0), H = Math.round(parseFloat(p[4]) || 0);
      var wt = parseFloat(p[5]) || 0;
      var dimW = L * W * H / 166;
      var billable = Math.max(wt, dimW);
      var ph = billable - wt;
      var cost = (rate[p[1] + "|" + Math.ceil(billable)] || 0) - (rate[p[1] + "|" + Math.ceil(wt)] || 0);
      if (ph > 0) { flagged++; lbs += ph; extra += cost; }
      out.push({ row: r + 1, order: p[0], service: p[1], dimW: dimW, billable: billable, phantom: ph, extra: cost });
    }
    return { rows: out, flagged: flagged, phantomLb: lbs, extra: extra, checked: out.length };
  }
  return { run: run };
})();
if (typeof module !== "undefined" && module.exports) module.exports = PHANTOM_V1;
