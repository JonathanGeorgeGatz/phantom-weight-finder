/* NOT THE TOOL — the SECOND build from Build It With AI, Episode 28, kept so you can see what went wrong. Use phantom.gs. */
/* EP28 SECOND BUILD — what prompt 2 produced, given the written rule. WRONG: kept as a museum piece, NOT THE TOOL.
   It reads like the rule and still disagrees with the checker in three places:
   1. it rounds the VOLUME up instead of each side (16.4 x 12.4 x 9.4 -> 1,912 cubic inches, not 17 x 13 x 10 = 2,210);
   2. it treats "more than 1,728" as "1,728 or more", so the exact 12-inch cube gets dimensional weight;
   3. it runs the cubic-priced services through the same rule instead of setting them aside. */
var PHANTOM_V2 = (function () {
  var OK = { "priority mail express": 1, "priority mail": 1, "ground advantage": 1, "parcel select": 1,
             "priority mail cubic": 1, "ground advantage cubic": 1 };
  function fold(s) { return String(s == null ? "" : s).replace(/\s+/g, " ").trim().toLowerCase(); }
  function num(s) { var t = String(s == null ? "" : s).trim(); return /^\d+(\.\d+)?$/.test(t) ? parseFloat(t) : null; }
  function run(pkgRows, boxRows, rateRows) {
    var rate = {};
    for (var i = 1; i < rateRows.length; i++) {
      var s = fold(rateRows[i][0]); var c = s.replace(" cubic", "");
      rate[c + "|" + parseInt(rateRows[i][1], 10)] = Math.round(parseFloat(rateRows[i][2]) * 100);
    }
    var rows = [], refused = [], seen = {};
    for (var r = 1; r < pkgRows.length; r++) {
      var p = pkgRows[r], ord = String(p[0]).trim(), svc = fold(p[1]);
      if (!ord) { refused.push({ row: r + 1, reason: "no order id" }); continue; }
      if (seen[ord.toLowerCase()]) { refused.push({ row: r + 1, reason: "duplicate order" }); continue; }
      seen[ord.toLowerCase()] = 1;
      if (!OK[svc]) { refused.push({ row: r + 1, reason: "unknown service" }); continue; }
      var L = num(p[2]), W = num(p[3]), H = num(p[4]), wt = num(p[5]);
      if (L == null || W == null || H == null || wt == null) { refused.push({ row: r + 1, reason: "unreadable" }); continue; }
      var vol = Math.ceil(L * W * H - 1e-9);                  // BUG 1: rounds the volume, not each side
      var dim = vol >= 1728 ? Math.ceil(vol / 139) : 0;       // BUG 2: ">=" — the 12-inch cube is caught
      var act = Math.ceil(wt - 1e-9), bill = Math.max(act, dim), ph = bill - act;
      var base = svc.replace(" cubic", "");                    // BUG 3: cubic services priced by this rule
      var extra = ph > 0 && rate[base + "|" + bill] != null && rate[base + "|" + act] != null ? rate[base + "|" + bill] - rate[base + "|" + act] : 0;
      rows.push({ row: r + 1, order: ord, volume: vol, dim: dim, actual: act, billable: bill, phantom: ph, extraCents: extra });
    }
    var ph = rows.filter(function (x) { return x.phantom > 0; });
    var lb = 0, ex = 0; ph.forEach(function (x) { lb += x.phantom; ex += x.extraCents; });
    return { rows: rows, refused: refused, phantomCount: ph.length, phantomLb: lb, extraCents: ex, checked: rows.length };
  }
  return { run: run };
})();
if (typeof module !== "undefined" && module.exports) module.exports = PHANTOM_V2;
