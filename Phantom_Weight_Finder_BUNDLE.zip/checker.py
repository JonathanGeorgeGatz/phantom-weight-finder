#!/usr/bin/env python3
"""EP28 — The Phantom Weight Finder — independent checker ("the referee").
Written from SPEC.md alone, never from the Apps Script. Same inputs (CSV exports of the four tabs),
same answers, computed a different way (Decimal arithmetic, its own parsing).
usage: python3 checker.py packages.csv boxes.csv rates.csv [settings.csv] [--json]"""
import csv, json, re, sys
from decimal import Decimal, ROUND_CEILING

INSCOPE = ["priority mail express", "priority mail", "ground advantage", "parcel select"]
CUBIC = ["priority mail cubic", "ground advantage cubic"]
NUM = re.compile(r"^\d+(\.\d{1,2})?$")

def clean(x): return " ".join(str(x if x is not None else "").split())
def key(x): return clean(x).lower()
def dec(x):
    t = clean(x)
    return Decimal(t) if NUM.match(t) else None
def up(d): return int(d.to_integral_value(rounding=ROUND_CEILING))
def price(x):
    t = clean(x)
    if t.startswith("$"): t = t[1:]
    return int(Decimal(t) * 100) if NUM.match(t) else None

def load(path):
    if path is None: return None
    try:
        with open(path, newline="") as f: return [r for r in csv.reader(f)]
    except FileNotFoundError: return None

def cols(rows, names):
    if not rows: return None
    head = [key(h) for h in rows[0]]
    if any(n not in head for n in names): return None
    return {n: head.index(n) for n in names}

def cell(row, i): return row[i] if i < len(row) else ""

def empty(row, ix): return all(clean(cell(row, i)) == "" for i in ix.values())

def check(pk, bx, rt, se):
    divisor, threshold, notes = 139, 1728, []
    for r in (se or [])[1:]:
        k, v = key(cell(r, 0)), clean(cell(r, 1))
        if k == "divisor":
            if v.isdigit() and 100 <= int(v) <= 300: divisor = int(v)
            else: notes.append("divisor unreadable — using 139")
        elif k == "threshold":
            if v.isdigit() and 0 <= int(v) <= 20000: threshold = int(v)
            else: notes.append("threshold unreadable — using 1728")

    def dimw(vol): return -(-vol // divisor) if vol > threshold else 0     # integer ceiling

    bad_headers = []
    ri = cols(rt, ["service", "pounds", "price"])
    card, rate_ref = {}, []
    if ri is None: bad_headers.append("Rates")
    else:
        for n, r in enumerate(rt[1:], start=2):
            if empty(r, ri): continue
            s, lb, pc = key(cell(r, ri["service"])), clean(cell(r, ri["pounds"])), price(cell(r, ri["price"]))
            if s not in INSCOPE: rate_ref.append([n, "unknown service: " + clean(cell(r, ri["service"]))]); continue
            if not (lb.isdigit() and 1 <= int(lb) <= 70): rate_ref.append([n, "pounds must be a whole number 1–70"]); continue
            if pc is None: rate_ref.append([n, "unreadable price"]); continue
            if (s, int(lb)) in card: rate_ref.append([n, "duplicate rate — the first was kept"]); continue
            card[(s, int(lb))] = pc

    bi = cols(bx, ["box", "length", "width", "height"])
    boxes, box_ref = [], []
    if bi is None: bad_headers.append("Boxes")
    else:
        for n, r in enumerate(bx[1:], start=2):
            if empty(r, bi): continue
            nm = clean(cell(r, bi["box"]))
            ds = [dec(cell(r, bi[c])) for c in ("length", "width", "height")]
            if not nm: box_ref.append([n, "no box name"]); continue
            if any(d is None or d <= 0 for d in ds): box_ref.append([n, "unreadable size"]); continue
            s = [up(d) for d in ds]; v = s[0] * s[1] * s[2]
            boxes.append({"name": nm, "sides": s, "volume": v, "dim": dimw(v)})

    pi = cols(pk, ["order", "service", "length", "width", "height", "weight"])
    rows_in, done, excl, refd = 0, [], [], []
    if pi is None:
        bad_headers.append("Packages")
        for n, r in enumerate((pk or [])[1:], start=2):
            if all(clean(c) == "" for c in r): continue
            rows_in += 1; refd.append([n, "", "Packages header row unreadable"])
    else:
        orders = set()
        for n, r in enumerate(pk[1:], start=2):
            if empty(r, pi): continue
            rows_in += 1
            o = clean(cell(r, pi["order"]))
            if o == "": refd.append([n, "", "no order id"]); continue
            if o.lower() in orders: refd.append([n, o, "duplicate order — the first row was kept"]); continue
            orders.add(o.lower())
            s = key(cell(r, pi["service"]))
            if s in CUBIC: excl.append([n, o, "cubic-priced: priced by cubic tier, not this rule"]); continue
            if s not in INSCOPE: refd.append([n, o, "unknown service: " + clean(cell(r, pi["service"]))]); continue
            ds = [dec(cell(r, pi[c])) for c in ("length", "width", "height")]
            if any(d is None or d <= 0 for d in ds): refd.append([n, o, "unreadable size"]); continue
            if any(d > 108 for d in ds): refd.append([n, o, "a side over 108 inches"]); continue
            w = dec(cell(r, pi["weight"]))
            if w is None or w <= 0: refd.append([n, o, "unreadable weight"]); continue
            if w > 70: refd.append([n, o, "over 70 lb"]); continue
            sides = [up(d) for d in ds]; vol = sides[0] * sides[1] * sides[2]
            dim = dimw(vol); act = up(w); bill = act if act >= dim else dim; ph = bill - act
            extra, priced, note, sug = 0, True, "", ""
            if ph > 0:
                hb, ha = (s, bill) in card, (s, act) in card
                if hb and ha: extra = card[(s, bill)] - card[(s, act)]
                else: priced, note = False, "no rate for %d lb" % (act if hb else bill)
                cands = [b for b in boxes if b["volume"] < vol and b["dim"] <= act]
                best = None
                for b in cands:
                    if best is None or b["volume"] > best["volume"]: best = b
                sug = best["name"] if best else "none in your list"
            done.append([n, o, "x".join(map(str, sides)), vol, dim, act, bill, ph, extra, priced, note, sug])

    ph_rows = [d for d in done if d[7] > 0]
    total = sum(d[8] for d in ph_rows if d[9])
    worst = None
    for d in ph_rows:
        if worst is None or (d[8], d[7]) > (worst[8], worst[7]): worst = d
    recon = rows_in == len(done) + len(excl) + len(refd)
    readd = sum(d[8] for d in done) == total
    why = []
    if bad_headers: why.append("header row unreadable: " + ", ".join(bad_headers))
    if not recon: why.append("rows do not add up")
    if not readd: why.append("money does not re-add")
    if rows_in and len(refd) / rows_in > 0.10: why.append("more than 10% of rows refused")
    if ri is not None and not card: why.append("no usable rates")
    return {
        "totals": {"rowsIn": rows_in, "checked": len(done), "phantomCount": len(ph_rows), "phantomLb": sum(d[7] for d in ph_rows),
                   "extraCents": total, "unpriced": sum(1 for d in ph_rows if not d[9]), "excluded": len(excl), "refused": len(refd),
                   "usableRates": len(card)},
        "trust": "DO NOT TRUST THESE WEIGHTS" if why else "OK", "trustReasons": why,
        "recon": {"ok": recon, "readdOK": readd}, "settings": {"divisor": divisor, "threshold": threshold, "notes": notes},
        "rows": done, "boxes": [[b["name"], "x".join(map(str, b["sides"])), b["volume"], b["dim"]] for b in boxes],
        "excluded": excl, "refused": refd, "rateRefusals": rate_ref, "boxRefusals": box_ref,
        "worst": [worst[0], worst[1]] if worst else None,
    }

if __name__ == "__main__":
    a = [x for x in sys.argv[1:] if not x.startswith("--")]
    res = check(load(a[0]), load(a[1]), load(a[2]), load(a[3]) if len(a) > 3 else None)
    if "--json" in sys.argv: print(json.dumps(res, ensure_ascii=False))
    else:
        t = res["totals"]
        print(res["trust"], *res["trustReasons"])
        print("packages in %d = checked %d + set aside %d + refused %d" % (t["rowsIn"], t["checked"], t["excluded"], t["refused"]))
        print("phantom weight on %d packages, %d lb, $%.2f extra on your rate card (%d unpriced)" % (t["phantomCount"], t["phantomLb"], t["extraCents"] / 100, t["unpriced"]))
