# EP28 — The Phantom Weight Finder — SPEC (frozen before any implementation; tie-breaks live HERE)

A Google Sheets + Apps Script tool. A shipper keeps a log of packages they sent through USPS. The
custom menu **Phantom Weight → Find phantom weight** works out what USPS bills each package at under
the dimensional-weight rule in force since July 12, 2026, flags every package billed above its real
weight (PHANTOM WEIGHT), prices the difference from the shop's OWN rate card, and checks the shop's
own box list. It sends nothing and buys nothing. Rules source: USPS Postal Bulletin 22705 (effective
July 12, 2026).

## Tabs read (headers on row 1, matched case-insensitively after trimming; extra columns ignored)
- **Packages**: `Order | Service | Length | Width | Height | Weight`
  (inches, inches, inches, pounds; decimals allowed)
- **Boxes**: `Box | Length | Width | Height` (the shop's own box sizes, inches)
- **Rates**: `Service | Pounds | Price` (the shop's own rate card for its usual zone; Pounds = whole pounds)
- **Settings** (optional): `Setting | Value` rows. `divisor` (default 139), `threshold` (cubic inches, default 1728).

A tab that is missing, or whose row 1 lacks any required header, is a **header failure** (see Trust).

## Numbers
- A dimension or weight cell: optional surrounding spaces, digits with at most 2 decimals
  (`12`, `12.5`, `12.25`); no units, no commas. Stored as integer hundredths. Anything else → unreadable.
- Price: optional `$`, digits with at most 2 decimals. Stored integer cents.
- Pounds (Rates): a whole number 1–70.
- Blank rows (every required cell empty) are skipped silently and not counted anywhere.

## Services (Packages and Rates, matched by `fold` = collapse inner whitespace, trim, lowercase)
- IN SCOPE: `priority mail express`, `priority mail`, `ground advantage`, `parcel select`.
- EXCLUDED (counted, not checked): `priority mail cubic`, `ground advantage cubic` → reason
  "cubic-priced: priced by cubic tier, not this rule".
- Anything else → REFUSED "unknown service: <cell as typed>".

## Packages: row order of checks (first failure wins; row numbers are sheet rows, header = row 1)
1. Order blank → refused "no order id".
2. Order already seen (fold) → refused "duplicate order — the first row was kept".
3. Service: excluded or refused per Services.
4. Length, Width, Height: unreadable or ≤ 0 → refused "unreadable size"; any side > 108 → refused "a side over 108 inches".
5. Weight: unreadable or ≤ 0 → refused "unreadable weight"; > 70 → refused "over 70 lb".
(The duplicate check happens before the service check: a duplicate of an excluded order is refused.)

## The rule (checked rows)
- Each side rounds UP to the next whole inch (an exact whole number stays). `L' W' H'`.
- `volume = L'·W'·H'` (cubic inches).
- If `volume > threshold` (strictly greater: a 12×12×12 box is exactly 1,728 and is NOT dimensional):
  `dim = ceil(volume / divisor)` whole pounds. Otherwise `dim = 0`.
- `actual = ceil(weight)` whole pounds (2.01 lb → 3).
- `billable = max(actual, dim)`. `phantom = billable − actual` (pounds, ≥ 0).
- A row with `phantom > 0` is a **PHANTOM WEIGHT** row.

## Money (from the shop's own Rates)
- `price(service, lb)` = the Rates row whose service folds equal and Pounds = lb.
- For a phantom row: if both `price(billable)` and `price(actual)` exist → `extra = price(billable) − price(actual)` cents; otherwise the row is **unpriced** (counted, extra = 0, note "no rate for N lb", where N = billable if its rate is missing, else actual).
- Rates rows: service not one of the four in-scope services → refused "unknown service: <cell>"; pounds not a whole number 1–70 → refused "pounds must be a whole number 1–70"; unreadable price → refused "unreadable price"; (in that order) (Rates refusals listed separately); a second row for the same service+pounds → refused "duplicate rate — the first was kept".

## Box check (Boxes tab)
- Each box: sides rounded up, volume, `dim` as above (0 if ≤ threshold). Unreadable box rows refused.
- **Suggestion** for each phantom row: among boxes with `boxVolume < package volume` (rounded volumes),
  the one with the LARGEST volume whose `max(actual, boxDim) == actual` (i.e. it would not add phantom
  weight for this package). Ties on volume → the box listed first. None → "none in your list".
  (The tool cannot know whether the contents fit; README says so.)

## Outputs (pure core returns; the .gs writes them to a sheet named `Phantom Weight`)
- per checked row: order, service (as typed), rounded sides, volume, dim, actual, billable, phantom, extra cents, priced flag, suggestion.
- totals: checked, phantomCount, phantomLb (sum), extraCents (sum over priced), unpricedCount, excluded, refused, rowsIn.
- worst: the phantom row with the highest extra (ties: higher phantom lb, then earlier row).
- boxes: name, rounded sides, volume, dim, flag "DIM" when dim > 0.
- refusals: Packages (row, order, reason), Rates (row, reason), Boxes (row, reason).

## Trust (self-audit)
- `rowsIn` = non-blank Packages rows. **Recon: rowsIn == checked + excluded + refused.**
- **Money re-add:** extraCents == sum of every row's extra.
- Banner `DO NOT TRUST THESE WEIGHTS` when ANY of: a header failure on Packages, Boxes or Rates; recon fails;
  re-add fails; refused share of rowsIn > 10%; Rates has zero usable rows. Otherwise `OK`.
- On a Packages header failure nothing is checked: rowsIn counts the non-blank rows, every one is reported
  as unreadable ("Packages header row unreadable"), totals zero, banner up.

## Settings
- `divisor`: a whole number 100–300. `threshold`: whole number 0–20000. Unreadable → default, plus a note.

## Formatting
- Money printed `$1,234.56`. Pounds as whole numbers.

## v1.1 — Box cost and net saving (added 2026-11-14, written BEFORE the code; tie-breaks live HERE)
Why: a viewer pointed out that a smaller box isn't free. Postage saved by a swap can be eaten by what the new box costs.
- **Boxes** gains an OPTIONAL column `Box cost` (header folds to `box cost`): dollars per box (box + fill), the shop's own number.
  - Column ABSENT → v1.0 behaviour exactly: same results, same report, nothing below applies (`swaps` = null).
  - Cell blank → cost unknown. Cell readable as a Price (optional `$`, digits, ≤ 2 decimals; `0` allowed) → cost in cents.
  - Anything else (text, negative, 3 decimals) → the box is KEPT (its size still counts for suggestions) but its cost is unknown,
    and a Boxes refusal is listed: `unreadable box cost — size kept, cost unknown`. Any such refusal raises the banner
    (reason `a box cost is unreadable`). A row refused for name/size is refused as before (its cost is never read).
- **Current box** of a checked package: the FIRST kept box (list order) whose rounded sides, sorted ascending, equal the
  package's rounded sides sorted ascending. None → no current box.
- **Swap** = a PHANTOM WEIGHT row whose suggestion is a box (not "none in your list"). For each swap:
  - `ship` (shipping saved): `newBill = max(actual, suggested box dim)`; if both `price(billable)` and `price(newBill)` exist →
    `price(billable) − price(newBill)` cents; else unknown.
  - `change` (box cost change): known only when the current box exists and BOTH its cost and the suggested box's cost are
    known → `suggested cost − current cost` cents (can be negative).
  - `net` = `ship − change`, known only when both are known.
  - **Status, first match wins:** ship unknown → `no rate — net unknown`; no current box → `your box isn't in the Boxes list — net unknown`;
    change unknown → `add box costs to see the net`; net ≤ 0 → `SWAP NOT WORTH IT`; otherwise `worth it`.
- **Swap totals** (only rows whose net is known): `known` (count), `swaps` (count of all swaps), `shipCents` = Σ ship,
  `changeCents` = Σ change, `netCents` = Σ net, `notWorth` = count with net ≤ 0.
- **Self-audit:** `netCents` must equal `shipCents − changeCents` (each summed separately, to the cent); otherwise banner reason
  `box savings do not re-add`.
- Phantom-weight totals, the worst package and every v1.0 output are unchanged by this section.
- Report (column present only): the phantom table gains `Box cost change` and `Net saving` (net or the status note;
  `SWAP NOT WORTH IT` appended to a net ≤ 0); a `BOX SWAPS` summary row; the box list gains `Box cost`.
